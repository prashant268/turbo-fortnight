from dotenv import load_dotenv
load_dotenv()
from langchain.prompts.prompt import PromptTemplate
from langchain.memory import ConversationBufferWindowMemory
from langchain_community.utilities import SQLDatabase

from langchain_core.prompts import PromptTemplate

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_experimental.sql.base import SQLDatabaseChain
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_community.utilities import SQLDatabase
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory
from langchain.chains import create_sql_query_chain
from math import acos,cos,sin, radians
import configparser
import pandas as pd
import psycopg2
import os
import sqlite3
from langchain_google_genai import GoogleGenerativeAIEmbeddings
import google.generativeai as genai
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
import retrying
import psycopg2
import pandas as pd
from langchain.chains import ConversationChain
from sqlalchemy import create_engine,inspect
from langchain_community.vectorstores import FAISS
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_openai import OpenAIEmbeddings
from langchain_community.agent_toolkits import create_sql_agent
from langchain_openai import ChatOpenAI
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.vectorstores import Chroma
import re
import utils as utils
gemini_api_key = 'AIzaSyA5prR7R_xX3AljwfCjMsy_MNb3UMCFDIc'
google_api_key='AIzaSyA5prR7R_xX3AljwfCjMsy_MNb3UMCFDIc'
llm = ChatGoogleGenerativeAI(model="gemini-pro", google_api_key=gemini_api_key, 
                         convert_system_message_to_human=True, temperature=0.0)
chain=llm
from langchain_core.prompts import (
    ChatPromptTemplate,
    FewShotPromptTemplate,
    MessagesPlaceholder,
    PromptTemplate,
    SystemMessagePromptTemplate,
)
def generate_sql(user_input):
    df=pd.read_csv("examples.csv")
    examples=df.to_dict(orient='records')
    example_selector = SemanticSimilarityExampleSelector.from_examples(
        examples,
        GoogleGenerativeAIEmbeddings(google_api_key=google_api_key,model = "models/embedding-001"),
        Chroma,
        k=1,
    )
    example_prompt = PromptTemplate(
        input_variables=[ "Human"],
        template="Human: {Human}\nSQL: {SQL}",
    )
    
    similar_prompt = FewShotPromptTemplate(
        # We provide an ExampleSelector instead of examples.
        example_selector=example_selector,
        example_prompt=example_prompt,
       
        prefix="",
        suffix="",
        input_variables=[ "Human"],
    )
    a=similar_prompt.format(Human=user_input)
    PROMPT_TEMPLATE = """You are a chatbot named AXON which generates sql query stored in "sqlite". 
    Dont generate response if question is not related to database respond with "i dont know".
    Your company maintains two database tables: "invoice" and "delivery" always use these table only
    Dont do any UPDATE,INSERT, DELETE query generation.
        invoice which has column names as following:
        ['invoiceno it is invoice id 
        'sales_order_no it is sales order number
        'amount' it is the price of items,currency type is M.A.D
        'invoicedate' date of invoice
        'itemname' it is name of item
        'plant'-delivery plant number
        'quantity'-it is quantity of orders
        'net_weight'-it is net weight of orders
        'customername'-it is customer name
        'customerid'-unique id for each customers
        ]
        second table is delivery:
        ['date_of_delivery',
          'tripno':this is trip id number,
            'invoiceno' this is invoice id , 
            'deliveryexecutiveempcode' this is delivery executive employee code,
            'deliveryexecutivename' this is delivery executive employee name, 
            'customerid' this is unique customer id when not asked for name use this column always, 
            'out_for_delivery'-this is column showing if delivery started from source or not,
            'delivery_status'-this column show is item delivered or not,
            'on_time_delivery'-this have three values 'late', 'on-time','nan'.
            ]
        Dont include ```, ```sql and \n in the output.
        {history}
    Human: {input}
    SQL:
    Instructions:
                Alway do a distinct count on customer id when question is related to customers
                Question: {input}
                Given an input question, first create a syntactically correct
                dialect sql query to run.
                double check the sql query generated should not have ```, ```sql and \n or any special character at prefix or suffix.
                Relevant pieces of previous conversation:
                Dont include ```, ```sql and \n in the output.
    
    examples:
    
    
    """
    print("example selected",a)
    PROMPT_TEMPLATE+=a
    PROMPT = PromptTemplate(
        input_variables=["input", "history"],
        template=PROMPT_TEMPLATE
    )
    memory = ConversationBufferMemory(memory_key="history")
    conversation = ConversationChain(
        llm=llm,
        verbose=False,
        prompt=PROMPT,
        memory=memory
    )
    response=conversation.predict(input=user_input)
    class SQLExtractor:
        def __init__(self):
            pass
        def extract_sql(self, llm_response: str) -> str:
            # If the llm_response contains a markdown code block, with or without the sql tag, extract the sql from it
            sql = re.search(r"```sql\n SQL:(.*)```", llm_response, re.DOTALL)
            if sql:
                # Log the original response and the extracted SQL
                print(f"Output from LLM: {llm_response} \nExtracted SQL: {sql.group(1)}")
                return sql.group(1)
    
            sql = re.search(r"```(.*)```", llm_response, re.DOTALL)
            if sql:
                # Log the original response and the extracted SQL
                print(f"Output from LLM: {llm_response} \nExtracted SQL: {sql.group(1)}")
                return sql.group(1)
    
            return llm_response
    
        def is_sql_valid(self, sql: str) -> bool:
            # This is a check to see the SQL is valid and should be run
            # This simple function just checks if the SQL contains a SELECT statement
            if "SELECT" in sql.upper():
                return True
            else:
                return False
    
    extractor = SQLExtractor()
    extracted_sql = extractor.extract_sql(response)
    
    if extractor.is_sql_valid(extracted_sql):
        try:
            sql=extracted_sql.split('SQL:', 1)[1]
        except:
            sql=extracted_sql
        return(sql)
    else:
        return response
    
def get_conversational_chain():  
    
    prompt_template ="""You are a chatbot having a conversation with a human.

    consider previous chat history {chat_history}.

    Given the following extracted parts of a document {context} and a question {human_input}, create a final answer with details explaining in natural human language.

    Strictly please don't give answers other than given in the given document and give asnwer in English language only.

    {context}

    {chat_history}
    Human: {human_input}
    Chatbot:"""
    prompt = PromptTemplate(
    input_variables=["chat_history", "human_input", "context"], template=prompt_template
    )
    model = ChatGoogleGenerativeAI(model="gemini-pro",google_api_key=google_api_key,convert_system_message_to_human=True, temperature=0, max_tokens=200,request_timeout=3)
    memory = ConversationBufferMemory(memory_key="chat_history", input_key="human_input")

    chain = load_qa_chain(
        model, chain_type="stuff", memory=memory, prompt=prompt
        )
    return chain

def user_input_chat(user_question):
    embeddings = GoogleGenerativeAIEmbeddings(model = "models/embedding-001")
    new_db = FAISS.load_local("faiss_prod_inex", embeddings,)
    docs = new_db.similarity_search(user_question)
    chain = get_conversational_chain()
    response = chain(
        {"input_documents":docs, "human_input": user_question}
        , return_only_outputs=True)
    return response["output_text"]             
       